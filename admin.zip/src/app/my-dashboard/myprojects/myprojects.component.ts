import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-myprojects',
  templateUrl: './myprojects.component.html',
  styleUrls: ['./myprojects.component.css'],

})
export class MyprojectsComponent implements OnInit {

  constructor(
     ) { }

  ngOnInit() {
  }

}
