import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-user-to-projects',
  templateUrl: './add-user-to-projects.component.html',
  styleUrls: ['./add-user-to-projects.component.css']
})
export class AddUserToProjectsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
